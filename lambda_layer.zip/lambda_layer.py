def greet(name):
    return f"Hello, {name} from the Lambda layer!"

